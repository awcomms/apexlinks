import{S as t,i as e,s as a}from"../../../chunks/index-3c306420.js";class o extends t{constructor(s){super(),e(this,s,null,null,a,{})}}export{o as default};
