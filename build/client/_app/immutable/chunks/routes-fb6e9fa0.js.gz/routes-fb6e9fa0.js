const s={index:"/",login:"/login",items:"/i",users:"/u",txts:"/t"};export{s as r};
