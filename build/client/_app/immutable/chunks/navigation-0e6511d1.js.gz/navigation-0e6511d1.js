import{c as e}from"./singletons-d1fb5791.js";e.disable_scroll_handling;const a=e.goto;e.invalidate;e.prefetch;e.prefetch_routes;e.before_navigate;e.after_navigate;export{a as g};
